#!/bin/sh
set -eu
cd "$(dirname "$0")"
docker build -t crucible-sidecar:685bbf55b4618a12e7ece396 ./oncall-2-seed-0/environment/mcp-server
