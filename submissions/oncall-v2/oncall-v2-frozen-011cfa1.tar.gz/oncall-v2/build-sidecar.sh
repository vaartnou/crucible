#!/bin/sh
set -eu
cd "$(dirname "$0")"
docker build -t crucible-sidecar:d38722fc1540e46068a42a5c ./oncall-2-seed-0/environment/mcp-server
