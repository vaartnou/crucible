# Frozen oncall@2 Harbor task — separate verifier

The agent investigates and repairs two overlapping service regressions through metrics,
logs, deployment history and operational tools, then reports both causes. Reads and
interventions advance the clock. A developing second fault requires investigating
residual impact and checking sustained recovery.

Reward is avoided failed requests against the same world's no-action trajectory,
multiplied by (0.6 + 0.2 * verified recovery + 0.2 * diagnosis credit), minus action
penalties and clamped to [0,1]. Recovery is probed for thirty additional simulated
minutes. The independent verifier writes /logs/verifier/reward.txt.

Requires Harbor 0.26.0 and Docker. From this extracted directory:

    shasum -a 256 -c SHA256SUMS
    sh build-sidecar.sh
    harbor lint oncall-2-seed-0
    harbor run -p . -a oracle -n 1

For a model run, set GOOGLE_GENERATIVE_AI_API_KEY in the launching environment:

    harbor run -p . -a opencode -m google/gemini-3.8-flash --api-key-name GOOGLE_GENERATIVE_AI_API_KEY --ak version=1.19.5 -n 1

After the agent stops, Harbor collects trusted episode evidence from mcp-server.
A fresh verifier container replays the actions with the same frozen engine and salt,
checks exact tool results and outcome, and recomputes the reward. Verifier dependencies
are installed at image build time. Agent-side reward files are ignored.

The fresh model run scored 0.644313711357698, with verified recovery, complete diagnosis,
60 calls and zero Harbor exceptions. Native regrading with this frozen verifier
reproduced that score exactly. The public-tool runbook scores 0.9004757202439811
on the same world. This one scenario does not establish a broad difficulty claim.

This is an intentionally published demonstration task. Its generated grade token,
solution token and scenario salt are included. No provider API key is included.
Use a new private export for held-out evaluation. Task files and the wheel are frozen;
external base-image tags and dependency-download services are not fully immutable.

Source revision and wheel hash are recorded in manifest.json. Full default Harbor
lint passes without exceptions. The older shared-verifier archive is preserved
separately in the repository.

Native regrade of the bundled model artifact:

    harbor trials regrade model -p /path/to/extracted/oncall-v2/oncall-2-seed-0 -o regrades
