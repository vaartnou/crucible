# Oncall overlapping incidents — Harbor submission

Diagnose and repair two overlapping service regressions using metrics, logs and operational tools. Reads and interventions advance time. Identify both causes and verify sustained recovery before closing the incident.

Reward is avoided failed requests against the same world with no intervention, multiplied by (0.6 + 0.2 * verified recovery + 0.2 * diagnosis credit), less action penalties, clamped to [0,1]. Recovery is probed for thirty additional simulated minutes. The verifier writes /logs/verifier/reward.txt.

From this directory, build the simulator once:

    sh build-sidecar.sh

Then run with Harbor 0.26.0, Docker and a configured Google API credential:

    harbor run -p . -a opencode -m google/gemini-3.8-flash --api-key-name GOOGLE_GENERATIVE_AI_API_KEY --ak version=1.19.5 -n 1

The task uses a live simulator sidecar and shared verification. Harbor default lint flags shared-verifier; task-file and configuration checks pass. Keep this task export private because it contains evaluator credentials and the world salt.

The attached submission-evidence.zip records a fresh model run: reward 0.714490883784987, verified recovery and correct diagnosis, 54 tool calls, zero Harbor exceptions. The runbook scores 0.9004757202439811 on the same world. A single playthrough does not establish a broad difficulty claim.
